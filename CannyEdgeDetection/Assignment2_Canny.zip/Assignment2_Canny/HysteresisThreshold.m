 
function BinaryEdgeImage = HysteresisThreshold(magnitudeImage,minThresh,maxThresh)

% Write your function here