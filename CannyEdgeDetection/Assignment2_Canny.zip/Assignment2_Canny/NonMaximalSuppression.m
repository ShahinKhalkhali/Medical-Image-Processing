 
function newMagnitudeImage = NonMaximalSuppression(magnitude,orientation)

% Write your function here